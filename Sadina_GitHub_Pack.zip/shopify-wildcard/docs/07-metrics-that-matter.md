# 07 — Metrics That Matter

- **Adoption:** weekly active users, time‑to‑first‑value, cohort retention
- **Quality:** evaluation harness pass rate, flagged output rate, user‑rated quality
- **Support:** contact volume, deflection rate, time‑to‑resolution
- **Business outcomes:** per‑use‑case metrics (e.g., prep time, response time, NPS/CSAT)
- **Risk:** open risks by severity, time‑to‑mitigation