# 08 — Proof Links

Add public links that demonstrate excellence (no confidential info):
- LinkedIn profile
- Blog / Substack posts
- Conference talks / podcasts
- Open‑source contributions or sample repos
- Articles that reference your work (if public)