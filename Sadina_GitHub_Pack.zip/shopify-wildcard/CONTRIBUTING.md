# Contributing

Thanks for taking the time to make this better.

- Propose changes via issues first; describe the problem you’re solving.
- Keep docs human and practical—examples beat theory.
- No confidential or internal information. Ever.