# Code of Conduct

Be welcoming. Be kind. Assume good intent. Disagree with ideas, not people.
No harassment or discrimination. We fix systems, not blame humans.

If something feels off, open an issue and tag it **code‑of‑conduct**.