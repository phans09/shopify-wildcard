# How to Post This on GitHub (2 mins)

1) Create **two repos**:
   - Your profile repo named exactly your GitHub username (e.g., `sadina` → `sadina/sadina`). Put the `sadina-profile/README.md` into it as `README.md`.
   - A portfolio repo called `shopify-wildcard`. Upload the whole `shopify-wildcard/` folder.

2) Update placeholders:
   - Add your LinkedIn URL and public contact email.
   - Drop in public links under `docs/08-proof-links.md`.

3) (Optional) Pin `shopify-wildcard` on your GitHub profile so it appears at the top.

That’s it—clean, human, and ready for recruiters.